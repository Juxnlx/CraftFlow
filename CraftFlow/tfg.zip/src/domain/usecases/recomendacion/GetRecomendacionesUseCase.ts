import { injectable, inject } from "inversify";
import "reflect-metadata";
import { TYPES } from "../../../core/types";
import { IGetRecomendacionesUseCase } from "../../interfaces/usecases/IRecomendacionUseCases";
import { IProyectoRepository } from "../../interfaces/repositories/IProyectoRepository";
import { IMaterialRepository } from "../../interfaces/repositories/IMaterialRepository";
import { IHerramientaRepository } from "../../interfaces/repositories/IHerramientaRepository";
import { IUsuarioRepository } from "../../interfaces/repositories/IUsuarioRepository";
import {
  ProyectoRecomendado,
  MaterialMatch,
  HerramientaMatch,
} from "../../entities/ProyectoRecomendado";
import { Material } from "../../entities/Material";
import { Herramienta } from "../../entities/Herramienta";
import { Usuario } from "../../entities/Usuario";

/**
 * Caso de uso que genera recomendaciones de proyectos para un usuario.
 *
 * Compara los materiales y herramientas del inventario del usuario con los
 * requisitos de cada proyecto público, calcula un porcentaje de compatibilidad
 * combinado y devuelve los resultados ordenados de mayor a menor match.
 *
 * Necesita 4 repositorios:
 * - IProyectoRepository: proyectos públicos
 * - IMaterialRepository: materiales del usuario
 * - IHerramientaRepository: herramientas del usuario
 * - IUsuarioRepository: nombre y foto del autor de cada proyecto
 *
 * @example
 * const recomendaciones = await getRecomendacionesUseCase.execute("user123");
 * // Devuelve proyectos ordenados por % de match descendente
 */
@injectable()
export class GetRecomendacionesUseCase implements IGetRecomendacionesUseCase {
  private _proyectoRepository: IProyectoRepository;
  private _materialRepository: IMaterialRepository;
  private _herramientaRepository: IHerramientaRepository;
  private _usuarioRepository: IUsuarioRepository;

  /**
   * @param proyectoRepository - Repositorio de proyectos inyectado
   * @param materialRepository - Repositorio de materiales inyectado
   * @param herramientaRepository - Repositorio de herramientas inyectado
   * @param usuarioRepository - Repositorio de usuarios inyectado
   */
  constructor(
    @inject(TYPES.IProyectoRepository) proyectoRepository: IProyectoRepository,
    @inject(TYPES.IMaterialRepository) materialRepository: IMaterialRepository,
    @inject(TYPES.IHerramientaRepository) herramientaRepository: IHerramientaRepository,
    @inject(TYPES.IUsuarioRepository) usuarioRepository: IUsuarioRepository
  ) {
    this._proyectoRepository = proyectoRepository;
    this._materialRepository = materialRepository;
    this._herramientaRepository = herramientaRepository;
    this._usuarioRepository = usuarioRepository;
  }

  /**
   * Ejecuta el motor de recomendaciones.
   *
   * Algoritmo:
   * 1. Obtiene materiales, herramientas del usuario y proyectos públicos
   * 2. Para cada proyecto, compara materiales y herramientas requeridos
   * 3. matchPercent combinado: (materiales + herramientas coincidentes) / total ítems
   * 4. canMake = true solo si tiene TODOS los materiales Y TODAS las herramientas
   * 5. Obtiene datos del autor con caché para no repetir consultas
   * 6. Ordena por matchPercent descendente
   *
   * @param idUsuario - ID del usuario para el que se generan recomendaciones
   * @returns Promesa que resuelve a un array de proyectos recomendados
   */
  async execute(idUsuario: string): Promise<ProyectoRecomendado[]> {
    // 1. Obtener inventario del usuario y proyectos públicos en paralelo
    const [misMateriales, misHerramientas, proyectosPublicos] = await Promise.all([
      this._materialRepository.getMaterialesPorUsuario(idUsuario),
      this._herramientaRepository.getHerramientasPorUsuario(idUsuario),
      this._proyectoRepository.getProyectosPublicos(),
    ]);

    const recomendaciones: ProyectoRecomendado[] = [];

    // Caché de autores para no consultar el mismo usuario varias veces
    const cacheAutores = new Map<string, Usuario>();

    // 2. Para cada proyecto, comparar materiales y herramientas
    for (const proyecto of proyectosPublicos) {
      // Omitir proyectos propios del usuario
      if (proyecto.idUsuario === idUsuario) continue;

      // 2a. Matching de materiales
      const materialesRequeridos = proyecto.materiales || [];
      const materialesMatch: MaterialMatch[] = materialesRequeridos.map((req) => ({
        nombre: req.nombre,
        categoria: req.categoria,
        loTieneElUsuario: misMateriales.some((m) =>
          this._esMaterialCompatible(req, m)
        ),
      }));

      // 2b. Matching de herramientas
      const herramientasRequeridas = proyecto.herramientas || [];
      const herramientasMatch: HerramientaMatch[] = herramientasRequeridas.map((req) => ({
        nombre: req.nombre,
        tipo: req.tipo,
        loTieneElUsuario: misHerramientas.some((h) =>
          this._esHerramientaCompatible(req, h)
        ),
      }));

      // 3. Calcular matchPercent combinado
      const totalItems = materialesMatch.length + herramientasMatch.length;
      const itemsTenidos =
        materialesMatch.filter((m) => m.loTieneElUsuario).length +
        herramientasMatch.filter((h) => h.loTieneElUsuario).length;
      const matchPercent =
        totalItems === 0 ? 100 : Math.round((itemsTenidos / totalItems) * 100);

      // 4. canMake = todo material y toda herramienta (si el proyecto no requiere
      //    nada, se considera que sí se puede hacer)
      const canMake = matchPercent === 100;

      // 5. Obtener datos del autor (con caché)
      let autor = cacheAutores.get(proyecto.idUsuario);
      if (!autor) {
        try {
          autor = await this._usuarioRepository.getUsuarioPorId(proyecto.idUsuario);
          cacheAutores.set(proyecto.idUsuario, autor);
        } catch {
          // Si el autor fue eliminado, usar valores por defecto
          autor = new Usuario(proyecto.idUsuario, "", "Usuario eliminado");
          cacheAutores.set(proyecto.idUsuario, autor);
        }
      }

      recomendaciones.push(
        new ProyectoRecomendado(
          proyecto,
          autor.nombre,
          autor.fotoPerfil,
          matchPercent,
          canMake,
          materialesMatch,
          herramientasMatch
        )
      );
    }

    // 6. Ordenar por matchPercent descendente
    recomendaciones.sort((a, b) => b.matchPercent - a.matchPercent);

    return recomendaciones;
  }

  /**
   * Normaliza un texto eliminando tildes y convirtiendo a minúsculas.
   * Se usa para comparar nombres sin que afecten diferencias de escritura
   * entre usuarios.
   *
   * @param texto - Texto a normalizar
   * @returns Texto en minúsculas y sin tildes
   */
  private _normalizarTexto(texto: string): string {
    return texto
      .toLowerCase()
      .normalize("NFD")
      .replace(/[̀-ͯ]/g, "");
  }

  /**
   * Compara dos nombres por palabras. Si más del 50% de las palabras
   * del texto requerido aparecen en el del usuario, se considera match.
   *
   * Esto tolera pequeñas diferencias de escritura y nombres más largos:
   * - "Hilo algodón verde" vs "Ovillo algodón verde menta" → match
   * - "Aguja crochet 3.5mm" vs "Aguja de crochet 3.5mm" → match
   *
   * @param textoRequerido - Nombre que pide el proyecto
   * @param textoUsuario - Nombre del material/herramienta del usuario
   * @returns true si coinciden al menos la mitad de las palabras
   */
  private _coincidenciaPorPalabras(
    textoRequerido: string,
    textoUsuario: string
  ): boolean {
    const palabrasRequerido = this._normalizarTexto(textoRequerido).split(/\s+/);
    const palabrasUsuario = this._normalizarTexto(textoUsuario).split(/\s+/);

    const coincidencias = palabrasRequerido.filter((palabra) =>
      palabrasUsuario.some((pu) => pu.includes(palabra) || palabra.includes(pu))
    );

    return coincidencias.length >= Math.ceil(palabrasRequerido.length / 2);
  }

  /**
   * Compara un material requerido por un proyecto con uno del inventario.
   *
   * Dos niveles:
   * 1. La categoría debe coincidir exactamente.
   * 2. Al menos el 50% de las palabras del nombre requerido deben aparecer
   *    en el nombre del material del usuario.
   *
   * @param materialRequerido - Material que pide el proyecto
   * @param materialUsuario - Material del inventario
   * @returns true si se considera que el usuario tiene ese material
   */
  private _esMaterialCompatible(
    materialRequerido: { nombre: string; categoria: string },
    materialUsuario: Material
  ): boolean {
    // La categoría debe coincidir exactamente
    if (
      this._normalizarTexto(materialRequerido.categoria) !==
      this._normalizarTexto(materialUsuario.categoria)
    ) {
      return false;
    }

    return this._coincidenciaPorPalabras(
      materialRequerido.nombre,
      materialUsuario.nombre
    );
  }

  /**
   * Compara una herramienta requerida por un proyecto con una del inventario.
   *
   * A diferencia de los materiales, el "tipo" de herramienta es texto libre
   * (no hay categorías cerradas). Por eso se consideran compatibles si
   * coinciden las palabras del tipo O del nombre.
   *
   * @param herramientaRequerida - Herramienta que pide el proyecto
   * @param herramientaUsuario - Herramienta del inventario
   * @returns true si se considera que el usuario tiene esa herramienta
   */
  private _esHerramientaCompatible(
    herramientaRequerida: { nombre: string; tipo: string },
    herramientaUsuario: Herramienta
  ): boolean {
    // Match por nombre
    if (
      this._coincidenciaPorPalabras(
        herramientaRequerida.nombre,
        herramientaUsuario.nombre
      )
    ) {
      return true;
    }

    // O match por tipo (ej: "Agujas de crochet" vs "agujas crochet")
    if (
      herramientaRequerida.tipo &&
      herramientaUsuario.tipo &&
      this._coincidenciaPorPalabras(
        herramientaRequerida.tipo,
        herramientaUsuario.tipo
      )
    ) {
      return true;
    }

    return false;
  }
}
