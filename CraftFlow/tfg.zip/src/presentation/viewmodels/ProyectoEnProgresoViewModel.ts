import { makeAutoObservable, runInAction } from "mobx";
import { container } from "../../core/container";
import { TYPES } from "../../core/types";
import {
  IIniciarProyectoUseCase,
  IGetProyectoEnProgresoUseCase,
  IActualizarProgresoUseCase,
  ICompletarProyectoUseCase,
  IGetProyectosCompletadosUseCase,
  IGetMisProyectosEnProgresoUseCase,
  IAbandonarProyectoUseCase,
} from "../../domain/interfaces/usecases/IProyectoEnProgresoUseCases";
import {
  ProyectoEnProgreso,
  PasoCompletado,
} from "../../domain/entities/ProyectoEnProgreso";

/**
 * ViewModel que gestiona el seguimiento de proyectos en realización.
 *
 * Centraliza:
 * - El proyecto que el usuario está haciendo ahora (proyectoActivo).
 * - El cronómetro que mide el tiempo invertido en la sesión actual.
 * - Los proyectos completados (para mostrar en el perfil).
 *
 * El cronómetro se gestiona aquí (en lugar de en la pantalla) para que
 * persista al cambiar de pestaña o pausar y reanudar dentro de la app.
 * El "tiempoActual" expuesto suma el tiempo acumulado de sesiones previas
 * más el tiempo de la sesión activa, ambos en segundos.
 */
export class ProyectoEnProgresoViewModel {
  /** Seguimiento que el usuario está realizando ahora (null si ninguno) */
  proyectoActivo: ProyectoEnProgreso | null = null;

  /** Historial de proyectos completados del usuario (perfil) */
  proyectosCompletados: ProyectoEnProgreso[] = [];

  /** Seguimientos en curso del usuario (Home "Sigue trabajando" y perfil "En proceso") */
  proyectosEnProgreso: ProyectoEnProgreso[] = [];

  isLoading: boolean = false;
  isSaving: boolean = false;
  mensajeError: string | null = null;

  /**
   * Tiempo total mostrado en pantalla (segundos). Suma del tiempo acumulado
   * en BD y el tiempo de la sesión activa actual.
   */
  tiempoActual: number = 0;

  // Marca temporal del inicio de la sesión actual (ms desde epoch).
  // 0 cuando el cronómetro está parado.
  private _sesionInicio: number = 0;

  // Tick del cronómetro que actualiza tiempoActual cada segundo.
  // Se guarda como any para evitar conflictos entre Node y browser timers.
  private _tickInterval: any = null;

  private _iniciarUseCase: IIniciarProyectoUseCase;
  private _getEnProgresoUseCase: IGetProyectoEnProgresoUseCase;
  private _actualizarUseCase: IActualizarProgresoUseCase;
  private _completarUseCase: ICompletarProyectoUseCase;
  private _getCompletadosUseCase: IGetProyectosCompletadosUseCase;
  private _getMisEnProgresoUseCase: IGetMisProyectosEnProgresoUseCase;
  private _abandonarUseCase: IAbandonarProyectoUseCase;

  constructor() {
    makeAutoObservable(this);
    this._iniciarUseCase = container.get<IIniciarProyectoUseCase>(
      TYPES.IIniciarProyectoUseCase
    );
    this._getEnProgresoUseCase = container.get<IGetProyectoEnProgresoUseCase>(
      TYPES.IGetProyectoEnProgresoUseCase
    );
    this._actualizarUseCase = container.get<IActualizarProgresoUseCase>(
      TYPES.IActualizarProgresoUseCase
    );
    this._completarUseCase = container.get<ICompletarProyectoUseCase>(
      TYPES.ICompletarProyectoUseCase
    );
    this._getCompletadosUseCase = container.get<IGetProyectosCompletadosUseCase>(
      TYPES.IGetProyectosCompletadosUseCase
    );
    this._getMisEnProgresoUseCase = container.get<IGetMisProyectosEnProgresoUseCase>(
      TYPES.IGetMisProyectosEnProgresoUseCase
    );
    this._abandonarUseCase = container.get<IAbandonarProyectoUseCase>(
      TYPES.IAbandonarProyectoUseCase
    );
  }

  /**
   * Abandona un proyecto en curso eliminando su seguimiento.
   * Actualiza la lista local para reflejar el cambio sin recargar.
   */
  async abandonarProyecto(idSeguimiento: string): Promise<boolean> {
    try {
      await this._abandonarUseCase.execute(idSeguimiento);
      runInAction(() => {
        this.proyectosEnProgreso = this.proyectosEnProgreso.filter(
          (s) => s.id !== idSeguimiento
        );
        if (this.proyectoActivo?.id === idSeguimiento) {
          this.proyectoActivo = null;
          this.tiempoActual = 0;
        }
      });
      return true;
    } catch (error) {
      runInAction(() => {
        this.mensajeError =
          error instanceof Error ? error.message : "Error al abandonar proyecto";
      });
      return false;
    }
  }

  /**
   * Carga la lista de seguimientos en curso del usuario.
   * Se usa en el Home ("Sigue trabajando") y en el perfil ("En proceso").
   */
  async cargarMisProyectosEnProgreso(idUsuario: string): Promise<void> {
    try {
      const lista = await this._getMisEnProgresoUseCase.execute(idUsuario);
      runInAction(() => {
        this.proyectosEnProgreso = lista;
      });
    } catch {
      // Silencioso: si falla, simplemente no se muestran
    }
  }

  /**
   * Carga el seguimiento activo del usuario sobre un proyecto, si existe.
   * Si no existe, deja proyectoActivo en null. Útil al entrar al detalle
   * de un proyecto para saber si el usuario ya lo había empezado.
   */
  async cargarSeguimiento(
    idUsuario: string,
    idProyecto: string
  ): Promise<void> {
    runInAction(() => {
      this.isLoading = true;
      this.mensajeError = null;
    });

    try {
      const seguimiento = await this._getEnProgresoUseCase.execute(
        idUsuario,
        idProyecto
      );
      runInAction(() => {
        this.proyectoActivo = seguimiento;
        this.tiempoActual = seguimiento?.tiempoInvertidoSegundos ?? 0;
        this.isLoading = false;
      });
    } catch (error) {
      runInAction(() => {
        this.mensajeError =
          error instanceof Error ? error.message : "Error al cargar seguimiento";
        this.isLoading = false;
      });
    }
  }

  /**
   * Inicia un nuevo seguimiento o recupera el existente.
   * Se llama cuando el usuario pulsa "Empezar" o "Continuar".
   */
  async iniciarProyecto(
    idUsuario: string,
    idProyecto: string,
    numeroPasos: number
  ): Promise<ProyectoEnProgreso | null> {
    runInAction(() => {
      this.isSaving = true;
      this.mensajeError = null;
    });

    try {
      const seguimiento = await this._iniciarUseCase.execute(
        idUsuario,
        idProyecto,
        numeroPasos
      );
      runInAction(() => {
        this.proyectoActivo = seguimiento;
        this.tiempoActual = seguimiento.tiempoInvertidoSegundos;
        this.isSaving = false;
      });
      return seguimiento;
    } catch (error) {
      runInAction(() => {
        this.mensajeError =
          error instanceof Error ? error.message : "Error al iniciar proyecto";
        this.isSaving = false;
      });
      return null;
    }
  }

  /**
   * Arranca el cronómetro de la sesión actual.
   * Cada segundo actualiza tiempoActual sumando 1 al valor base.
   */
  iniciarCronometro(): void {
    if (this._tickInterval) return; // ya está corriendo
    this._sesionInicio = Date.now();
    this._tickInterval = setInterval(() => {
      runInAction(() => {
        this.tiempoActual = this.tiempoActual + 1;
      });
    }, 1000);
  }

  /**
   * Pausa el cronómetro y guarda el tiempo acumulado en Firestore.
   * Se llama al salir de la pantalla de realización para no perder progreso.
   */
  async pausarCronometro(): Promise<void> {
    if (this._tickInterval) {
      clearInterval(this._tickInterval);
      this._tickInterval = null;
    }
    this._sesionInicio = 0;

    if (this.proyectoActivo) {
      await this._actualizarUseCase.execute(this.proyectoActivo.id, {
        tiempoInvertidoSegundos: this.tiempoActual,
      });
    }
  }

  /**
   * Marca un paso como completado o no completado y opcionalmente
   * añade una foto de progreso. Persiste el cambio inmediatamente.
   */
  async marcarPaso(
    numeroOrden: number,
    completado: boolean,
    fotoProgreso: string | null = null
  ): Promise<void> {
    if (!this.proyectoActivo) return;

    const nuevosPasos: PasoCompletado[] = this.proyectoActivo.pasosCompletados.map(
      (p) =>
        p.numeroOrden === numeroOrden
          ? { ...p, completado, fotoProgreso: fotoProgreso ?? p.fotoProgreso }
          : p
    );

    // Optimista: actualizar UI primero, luego persistir
    runInAction(() => {
      if (this.proyectoActivo) {
        this.proyectoActivo.pasosCompletados = nuevosPasos;
      }
    });

    try {
      await this._actualizarUseCase.execute(this.proyectoActivo.id, {
        pasosCompletados: nuevosPasos,
      });
    } catch (error) {
      runInAction(() => {
        this.mensajeError =
          error instanceof Error ? error.message : "Error al actualizar paso";
      });
    }
  }

  /**
   * Cierra el seguimiento marcándolo como completado, con foto del
   * resultado y nota opcional. Guarda también el tiempo final acumulado.
   */
  async completarProyecto(
    imagenResultado: string | null,
    notaFinal: string | null
  ): Promise<boolean> {
    if (!this.proyectoActivo) return false;

    runInAction(() => {
      this.isSaving = true;
      this.mensajeError = null;
    });

    try {
      // Asegurar que el tiempo final está guardado antes de completar
      await this._actualizarUseCase.execute(this.proyectoActivo.id, {
        tiempoInvertidoSegundos: this.tiempoActual,
      });
      await this._completarUseCase.execute(
        this.proyectoActivo.id,
        imagenResultado,
        notaFinal
      );
      runInAction(() => {
        this.proyectoActivo = null;
        this.tiempoActual = 0;
        this.isSaving = false;
      });
      return true;
    } catch (error) {
      runInAction(() => {
        this.mensajeError =
          error instanceof Error ? error.message : "Error al completar proyecto";
        this.isSaving = false;
      });
      return false;
    }
  }

  /**
   * Carga los proyectos completados del usuario (para el perfil).
   */
  async cargarCompletados(idUsuario: string): Promise<void> {
    try {
      const completados = await this._getCompletadosUseCase.execute(idUsuario);
      runInAction(() => {
        this.proyectosCompletados = completados;
      });
    } catch {
      // Silencioso: si falla, simplemente no se muestran los completados
    }
  }
}
