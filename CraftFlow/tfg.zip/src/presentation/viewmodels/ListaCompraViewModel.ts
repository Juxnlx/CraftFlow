import { makeAutoObservable, runInAction } from "mobx";
import { container } from "../../core/container";
import { TYPES } from "../../core/types";
import { IGetListaCompraUseCase } from "../../domain/interfaces/usecases/IListaCompraUseCases";
import { ItemCompra } from "../../domain/entities/ItemCompra";

/**
 * ViewModel que gestiona la lista de la compra del usuario.
 * Calcula qué materiales y herramientas faltan para hacer los proyectos
 * guardados como favoritos y expone el progreso global.
 */
export class ListaCompraViewModel {
  items: ItemCompra[] = [];
  isLoading: boolean = false;
  mensajeError: string | null = null;

  private _getListaCompraUseCase: IGetListaCompraUseCase;

  constructor() {
    makeAutoObservable(this);
    this._getListaCompraUseCase = container.get<IGetListaCompraUseCase>(
      TYPES.IGetListaCompraUseCase
    );
  }

  /**
   * Calcula la lista de la compra para el usuario actual.
   * Se llama desde la pantalla cada vez que entra o al pull-to-refresh.
   */
  async cargarLista(idUsuario: string): Promise<void> {
    runInAction(() => {
      this.isLoading = true;
      this.mensajeError = null;
    });

    try {
      const items = await this._getListaCompraUseCase.execute(idUsuario);
      runInAction(() => {
        this.items = items;
        this.isLoading = false;
      });
    } catch (error) {
      runInAction(() => {
        this.mensajeError =
          error instanceof Error ? error.message : "Error al cargar la lista";
        this.isLoading = false;
      });
    }
  }

  /** @returns Cantidad total de ítems pendientes */
  get totalItems(): number {
    return this.items.length;
  }

  /** @returns Cantidad de materiales pendientes */
  get totalMateriales(): number {
    return this.items.filter((i) => !i.esHerramienta).length;
  }

  /** @returns Cantidad de herramientas pendientes */
  get totalHerramientas(): number {
    return this.items.filter((i) => i.esHerramienta).length;
  }
}
